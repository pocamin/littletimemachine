class SecurityFilters{
    def static Map autorized = new HashMap()
    def static final int ALLOW_ALL = 0;
    def static final int ALLOW_USER_A = 1;
    def static final int ALLOW_USER_R = 2;
    def static final int ALLOW_FIRM = 3;


    static {
        autorized.put("firm#connect",ALLOW_ALL);
        autorized.put("recruterAccount#create",ALLOW_FIRM);
        autorized.put("recruterAccount#save",ALLOW_FIRM);
        autorized.put("recruterAccount#show",ALLOW_ALL);
        autorized.put("recruterAccount#edit",ALLOW_FIRM);
        autorized.put("connection#admin",ALLOW_ALL);
        autorized.put("connection#logout",ALLOW_ALL);
        autorized.put("firm#edit",ALLOW_FIRM);
        autorized.put("connection#login",ALLOW_ALL);
        autorized.put("recruterAccount#list",ALLOW_FIRM);
        autorized.put("recruterAccount#update",ALLOW_FIRM);
        autorized.put("jobOffer#create",ALLOW_FIRM);
        autorized.put("jobOffer#update",ALLOW_FIRM);
        autorized.put("jobOffer#save",ALLOW_FIRM);
        autorized.put("jobOffer#edit",ALLOW_FIRM);
        autorized.put("skillType#searchAJAX",ALLOW_ALL);
        autorized.put("jobOffer#addRequieredSkills",ALLOW_ALL);
        autorized.put("jobOffer#addPreferredSkills",ALLOW_ALL);
        autorized.put("city#areaChoosedAJAX",ALLOW_ALL);
        autorized.put("jobOffer#show",ALLOW_ALL);
        autorized.put("jobOffer#list",ALLOW_ALL);
        autorized.put("firm#update",ALLOW_FIRM);
        autorized.put("firm#show",ALLOW_ALL);
        autorized.put("firm#logo",ALLOW_ALL);
        autorized.put("applicantAccount#show",ALLOW_USER_A);
        autorized.put("applicantAccount#edit",ALLOW_USER_A);
        autorized.put("applicantAccount#update",ALLOW_USER_A);
        autorized.put("applicantAccount#create",ALLOW_ALL);
        autorized.put("applicantAccount#save",ALLOW_ALL);
        autorized.put("resume#create",ALLOW_USER_A);
        autorized.put("resume#update",ALLOW_USER_A);
        autorized.put("resume#edit",ALLOW_USER_A);
        autorized.put("resume#save",ALLOW_USER_A);
        autorized.put("resume#show",ALLOW_USER_A);
        autorized.put("resume#list",ALLOW_USER_A);
        autorized.put("resume#addStudy",ALLOW_USER_A);
        autorized.put("resume#addExp",ALLOW_USER_A);
    }



    def filters = {
        securityCheck(controller:'*', action:'*') {
            before = {

                def key = controllerName + "#" + actionName
                int value = autorized[key];
                println(key + " " + value);


                // On peut tout faire en admin
                if (isAdmin(session)){
                    return true;
                }

                if (value == ALLOW_ALL){
                    return true;
                }

                if (value == ALLOW_USER_A && session.applicant != null){
                    if (params['applicantAccount.id'] != null){
                        if (params['applicantAccount.id'].toString().equals(session.applicant?.toString())){
                            return true;
                        }
                    } else {
                        return true;
                    }
                }

                if (value == ALLOW_USER_R && session.recruter != null){
                    if (params['recruter.id'] != null){
                        if (params['recruter.id'].toString().equals(session.recruter?.toString())){
                            return true;
                        }
                    } else {
                        return true;
                    }
                }

                if (value == ALLOW_FIRM && session.firm != null){
                    if (params['firm.id'] != null){
                        if (params['firm.id'].toString().equals(session.firm?.toString())){
                            return true;
                        }
                    } else {
                        return true;
                    }
                }

                flash.message = "Problème de sécurité : " + key + " " + value
                redirect(uri:'/')
                return false

            }
        }
    }

    private def isAdmin(session) {
        if (true.equals(session.admin)){
            return true
        }
        return false
    }


}
