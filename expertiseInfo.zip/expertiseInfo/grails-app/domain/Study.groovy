class Study {
    static belongsTo = [school:School,diploma: Diploma]

    String description
    Date startDate
    Date endDate

    static def constraints = {
        description(nullable:true)
    }
}
