class City implements Comparable{
    static belongsTo = [area:Area]
    Area area
    String name
    
    int compareTo(o) {
        return name.compareTo(o.name)
    }

    static def constraints = {
        name(size:2..50,unique:'area')
        area(nullable:false)
    }

    String toString() {
      return name
    }

  
}
