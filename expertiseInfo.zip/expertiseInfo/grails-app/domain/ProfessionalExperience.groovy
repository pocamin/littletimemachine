class ProfessionalExperience {
    static belongsTo = [firm:Firm]

    Firm firm

    Date startDate

    Date endDate

    String description


    static def constraints = {
        description(blank:true)
        firm(nullable:false)
    }

}
