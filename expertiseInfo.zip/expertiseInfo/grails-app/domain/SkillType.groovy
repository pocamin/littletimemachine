class SkillType {
    static hasMany = [tests:Test]

    String name
    int skillDomain
    boolean validated = false

    static def constraints = {
        name(size:1..100)
    }

}
