class Diploma {
    static belongsTo = [school:School]

    String name

    boolean validated = false;

    static constraints={
        name(nullable:false)
    }



}
