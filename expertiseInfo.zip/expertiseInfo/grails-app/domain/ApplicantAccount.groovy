class ApplicantAccount extends Account {
  static hasMany = [resumes:Resume, testResults : TestResult, hiddenFor : Firm]

  Date birthDay
  String tel
  String address

  static constraints={
      birthDay(nullable:false)
      tel(size:6..20)
      address(size:2..1000)
  }    
}
