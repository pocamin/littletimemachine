class Question {
    static hasMany = [possibleAnswers:PossibleAnswer]
    static belongsTo = [test:Test]

    String description

    Byte[] image

     static def constraints = {
        description(size:10..500)
        image(nullable:true)
    }



}
