class PossibleAnswer {
    String description
    boolean good = false;

    static def constraints = {
        description(size:1..200)
    }

}
