class Constant {
  static final int OCCUPATION_TYPE = 1
  static final int JOB_TYPE = 2
  static final int SKILL_DOMAIN = 3
  static final Map CONSTANT_TYPE = [
          1:"Type de domaine d'activité",
          2:"Type de Contrat",
          3:"domaine de compétence"]



  int constantGroup
  String stringValue
  Long longValue

    static def constraints = {
        stringValue(blank:true)
        longValue(nullable:true)
    }

}
