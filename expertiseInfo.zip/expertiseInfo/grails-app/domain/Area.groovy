class Area {
    static belongsTo = [country:Country]
    static hasMany = [cities:City]
    Country country
    String name

    String toString() {
        return name
    }

    static constraints={
      name(blank:false)
    }


}
