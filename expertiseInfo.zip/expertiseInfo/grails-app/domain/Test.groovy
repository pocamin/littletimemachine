class Test {
    static belongsTo = [skillType:SkillType]
    static hasMany = [questions:Question]
    String name
    long level

    static def constraints = {
        name(size:1..100)
    }

}
