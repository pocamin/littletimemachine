class Skill {
    static belongsTo = SkillType

    int level

    String relatedExperience


    static def constraints = {
        relatedExperience(nullable:true)
    }

}
