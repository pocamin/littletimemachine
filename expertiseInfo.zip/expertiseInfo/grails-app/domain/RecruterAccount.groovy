class RecruterAccount extends Account{
    static belongsTo = [firm:Firm]

    Firm firm;

    static constraints={
        firm(nullable:false)
    }


}
