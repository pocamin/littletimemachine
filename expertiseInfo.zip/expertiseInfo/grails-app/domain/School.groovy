class School {
    String name

    static def constraints = {
        name(size:5..50)
    }
}
