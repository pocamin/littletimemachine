class Country {
    static hasMany = [areas:Area]
    String name
    String toString() {
        return name
    }

    static constraints={
        name(blank:false)
    }

}
