class Firm {
    static hasMany = [recruters:RecruterAccount]
    static belongsTo = [city:City]

    List recruters;
    City city;

    String name
    Byte[] logo
    String logoContentType
    String description
    String address
    String hrContact
    String mail
    String url
    boolean validated = false;
    
    static def constraints = {
        name(size:2..100,unique:true)
        url(nullable:true)
        description(nullable:true)
        address(nullable:true)
        hrContact(nullable:true)
        mail(nullable:true)
        logo(nullable:true)
        logoContentType(nullable:true)
        city(nullable:true)
    }


}
