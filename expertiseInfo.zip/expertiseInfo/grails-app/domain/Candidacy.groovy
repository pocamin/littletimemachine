class Candidacy {
    static belongsTo = [applicant:ApplicantAccount]

    ApplicantAccount applicant
    Resume resume
    String object
    String description
    int status = 0


    static constraints={
        description(size:0..1000)
        object(size:0..200)
        resume(nullable:true)
        applicant(nullable:false)
    }





}
