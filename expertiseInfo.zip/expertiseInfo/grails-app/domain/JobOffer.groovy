class JobOffer {
    static belongsTo = [firm:Firm,city:City,occupation:Occupation]
    static hasMany = [requieredSkills:SkillType,preferredSkills:SkillType]

    String name
    Date jobStartDate = new Date()
    Date offerStartDate = new Date()
    Date offerEndDate = new Date() + 90
    String description
    String salary
    String reference
    String contact
    Firm firm
    City city
    Occupation occupation
    List requieredSkills = new ArrayList()
    List preferredSkills = new ArrayList()
    long jobType
    boolean visible = true


    static def constraints = {
        name(size:2..200)
        description(size:20..5000)
        salary(size:0..20)
        reference(size:0..50)
        contact(size:0..200)
        firm(nullable:false)
        city(nullable:false)
        occupation(nullable:false)
    }



}
