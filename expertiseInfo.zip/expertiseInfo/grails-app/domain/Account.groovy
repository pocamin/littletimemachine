class Account {
  String email;
  String password;
  String firstName;
  String lastName;


  static constraints={
      email(email:true,blank:false,unique:true)
      password(size:6..20)
      firstName(size:2..30)
      lastName(size:2..30)
  }


}
