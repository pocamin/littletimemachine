class Occupation {
    String name
    long occupationType


    static def constraints = {
        name(size:2..200)
    }
}
