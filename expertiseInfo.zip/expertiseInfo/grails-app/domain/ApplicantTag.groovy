class ApplicantTag {
    static belongsTo = [applicant:ApplicantAccount]
    String name

    static constraints={
      name(size:1..200)
    }




}
