class TestResult {
    static belongsTo = [applicant:ApplicantAccount, test:Test]
    ApplicantAccount  applicant
    Test test
    Date date
    int score

    static def constraints = {
        applicant(nullable:false)
        test(nullable:false)
    }
}
