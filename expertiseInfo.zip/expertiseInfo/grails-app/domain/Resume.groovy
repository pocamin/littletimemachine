class Resume {
  static belongsTo = [applicant:ApplicantAccount]
  static hasMany = [professionalExperiences:ProfessionalExperience,studies:Study, skills : Skill]

  String name

  String description

  String otherInformations

  boolean hidden = false
}
