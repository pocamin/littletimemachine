            
class SkillTypeController {
    
    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']


    def searchAJAX = {
        String s = "%" + String.valueOf(params.query).toUpperCase() + "%";
        def skills = SkillType.findAll("from SkillType as s where upper(s.name) like ? and validated = true ",s);

        render(contentType: "text/xml") {
            results() {
                skills.each { skill ->
                    result(){
                        name(skill.name)
                    }
                }
            }
        }
    }


    def list = {
        if(!params.max) params.max = 10
        [ skillTypeList: SkillType.list( params ) ]
    }

    def show = {
        def skillType = SkillType.get( params.id )

        if(!skillType) {
            flash.message = "SkillType not found with id ${params.id}"
            redirect(action:list)
        }
        else { return [ skillType : skillType ] }
    }

    def delete = {
        def skillType = SkillType.get( params.id )
        if(skillType) {
            skillType.delete()
            flash.message = "SkillType ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "SkillType not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def skillType = SkillType.get( params.id )

        if(!skillType) {
            flash.message = "SkillType not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ skillType : skillType ]
        }
    }

    def update = {
        def skillType = SkillType.get( params.id )
        if(skillType) {
            skillType.properties = params
            if(!skillType.hasErrors() && skillType.save()) {
                flash.message = "SkillType ${params.id} updated"
                redirect(action:show,id:skillType.id)
            }
            else {
                render(view:'edit',model:[skillType:skillType])
            }
        }
        else {
            flash.message = "SkillType not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        def skillType = new SkillType()
        skillType.properties = params
        return ['skillType':skillType]
    }

    def save = {
        def skillType = new SkillType(params)
        if(!skillType.hasErrors() && skillType.save()) {
            flash.message = "SkillType ${skillType.id} created"
            redirect(action:show,id:skillType.id)
        }
        else {
            render(view:'create',model:[skillType:skillType])
        }
    }
}