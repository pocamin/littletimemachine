
class ApplicantAccountController {

    boolean visible = true;


    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']

    def list = {
        if(!params.max) params.max = 10
        [ applicantAccountList: ApplicantAccount.list( params ) ]
    }

    def show = {
        def applicantAccount = ApplicantAccount.get( session.applicant )

        if(!applicantAccount) {
            flash.message = "ApplicantAccount not found with id ${params.id}"
            redirect(action:list)
        }
        else { return [ applicantAccount : applicantAccount ] }
    }

    def delete = {
        def applicantAccount = ApplicantAccount.get( params.id )
        if(applicantAccount) {
            applicantAccount.delete()
            flash.message = "ApplicantAccount ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "ApplicantAccount not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def applicantAccount = ApplicantAccount.get( session.applicant )

        if(!applicantAccount) {
            flash.message = "ApplicantAccount not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ applicantAccount : applicantAccount ]
        }
    }

    def update = {
        params.each {key,value ->
            if ("".equals(value)){
                params.put(key,null);
            }
        }

        def applicantAccount = ApplicantAccount.get( session.applicant )

        if(applicantAccount) {
            def error = false
            def oldPassword =applicantAccount.password
            applicantAccount.properties = params
            if (params.password != null){
                if (! oldPassword.equals(params.oldPassword) ){
                    applicantAccount.errors.rejectValue('password','applicantAccount.wrong.password')
                    params.remove("password");
                    error = true
                } else if (!params.password.equals(params.password2)){
                    applicantAccount.errors.rejectValue('password','applicantAccount.unmatching.password')
                    params.remove("password");
                    error = true
                }
            } else {
                applicantAccount.password = oldPassword;
            }
            



            if(!applicantAccount.hasErrors() && !error && applicantAccount.save()) {
                flash.message = "Votre profil a été modifié"
                redirect(action:show,id:applicantAccount.id)
            }
            else {
                render(view:'edit',model:[applicantAccount:applicantAccount])
            }
        }
        else {
            flash.message = "ApplicantAccount not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        ApplicantAccount applicantAccount = ApplicantAccount.get(session.applicant);
        return ['applicantAccount':applicantAccount]
    }




    def save = {

        params.each {key,value ->
            if ("".equals(value)){
                params.put(key,null);
            }
        }


        def applicantAccount = new ApplicantAccount(params)

        if (!params.password.equals(params.password2))
            applicantAccount.errors.rejectValue('password','applicantAccount.unmatching.password')
        

        if(!applicantAccount.hasErrors() && applicantAccount.save()) {
            flash.message = "votre profil a été créé"
            redirect(action:show,id:applicantAccount.id)
        }
        else {
            render(view:'create',model:[applicantAccount:applicantAccount])
        }
    }
}