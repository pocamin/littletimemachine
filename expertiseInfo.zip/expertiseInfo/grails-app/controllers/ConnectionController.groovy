class ConnectionController {

    def index = { }

    def logout = {
        session.invalidate();
        redirect(uri:"/");
    }

    def admin = {
        if (params.id.equals("admin"))
            session.admin=true
        redirect(uri:"/");
    }

    def login = {

        Account account = Account.findByEmailAndPassword(params.email,params.password)
        if (account){
            if (account instanceof ApplicantAccount){
                session.applicant = account.id;
                session.removeAttribute('recruter')
                redirect(controller:"applicantAccount",action:"show");
                return;
            } else
            if (account instanceof RecruterAccount){

                session.recruter = account.id;
                session.firm = account.firm.id 
                session.removeAttribute('applicant')
            }
        } else {
            flash.connection = "email ou mot de passe invalide"
        }
        redirect(uri:"/");
    }

}
