class InitController {

    boolean visible = true;

    def index = {
        if (!Country.get(1)){
            println("createCountry");
            createCountry()

            println("createArea");
            createArea()

            println("createCity");
            createCity()

            println("createOccupation");
            createOccupation()

            println("createContractType");
            createContractType()

            println("createSkill");
            createSkill()

            println("createAccount");
            createAccount()

            println("createFirm");
            createFirm();


        }
        redirect(controller:"occupation",action:"list")
    }

    void createFirm(){
        InputStream is = new FileInputStream("listEntreprise.txt")
        is.eachLine{
            String[] str = it.split(";");
            def firm;
            if (str[0] != "")
                firm = new Firm(url:str[0],name:str[1],validated:true)
            else
                firm = new  Firm(name:str[1],validated:true);
            firm.save();
        }
    }

    void createAccount(){
        ApplicantAccount applicantAccount = new ApplicantAccount(birthDay:new Date(),firstName:"Benjamin",lastName:"Leroux",address:"27 Rue Faubourg Saint Denis",tel:"06.25.21.49.03",email:"benja.leroux@gmail.com",password:"benjam")
        println(applicantAccount.hasErrors());
        applicantAccount.save()
    }



    void createSkill() {
        def constant;
        constant = new Constant(stringValue:"Programation objet",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"Java",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"C++",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"C#",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Ruby",skillDomain:constant.id).save();

        constant = new Constant(stringValue:"Programation procédurale",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"C",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"VBA",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Assembleur",skillDomain:constant.id).save();

        constant = new Constant(stringValue:"Informatique industrielle",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"Catia",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Gemio",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Enovia",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Solidworks",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"readsoft",skillDomain:constant.id).save();

        constant = new Constant(stringValue:"Programation web",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"HTML",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"ASP",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"DotNet",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"JSP",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Servlets",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Web Services",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Javascript",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Flash",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"PHP",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"XML",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"XSL",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"CSS",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"GWT",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Coldfusion",skillDomain:constant.id).save();

        constant = new Constant(stringValue:"Framework JAVA",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"JSF",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Struts",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Hibernate",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Grails",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Seam",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Spring",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"TestNG",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"JUnit",skillDomain:constant.id).save();

        constant = new Constant(stringValue:"Serveurs d'application",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"Weblogic",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Websphere",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Glassfish",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Apache",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"JBoss",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"IIS",skillDomain:constant.id).save();

        constant = new Constant(stringValue:"Base de données",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"Access",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Oracle",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"PLSQL",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"SQL Server",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Mysql",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Postgre",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Paradox",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Informix",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"db2",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Sybase",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Autre",skillDomain:constant.id).save();
        constant = new Constant(stringValue:"Système d'exploitation",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"MS-DOS",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Unix/Linux",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Windows",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Mac/OS",skillDomain:constant.id).save();

        constant = new Constant(stringValue:"Administration Système",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"Administration Unix/Linux",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Administratrion Windows",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"AS/400",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"San",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Exchange",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"LOTUS Domino",skillDomain:constant.id).save();

        constant = new Constant(stringValue:"Administration Réseaux",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"TCP/IP",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"ATM",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"DNS",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"FTP",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"CFTP",skillDomain:constant.id).save();

        constant = new Constant(stringValue:"Methodes/outils",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"Mérise",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"UML",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Eclipse",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"NetBeans",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"CVS/Subversion",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Intégration continue",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"MS project",skillDomain:constant.id).save();
        
        constant = new Constant(stringValue:"Décisionnelle/DatawareHouse",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"SAS",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Business Intelligence",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Business Object",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Informatica",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Datastage",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"ESSBASE",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"OWB",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Crystal Reports",skillDomain:constant.id).save()

        constant = new Constant(stringValue:"ERP/CRM",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"SAP",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"PAYE",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"HR access",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Oracle Application",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"Siebel",skillDomain:constant.id).save();

        constant = new Constant(stringValue:"Autre",constantGroup:Constant.SKILL_DOMAIN).save()
        new SkillType(validated:true,name:"TOIP",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"VOIP",skillDomain:constant.id).save();
        new SkillType(validated:true,name:"DART",skillDomain:constant.id).save();

    }


    void createContractType() {
        new Constant(stringValue:"CDI",constantGroup:Constant.JOB_TYPE).save()
        new Constant(stringValue:"CDD",constantGroup:Constant.JOB_TYPE).save()
        new Constant(stringValue:"Stage",constantGroup:Constant.JOB_TYPE).save()
        new Constant(stringValue:"Freelance",constantGroup:Constant.JOB_TYPE).save()
        new Constant(stringValue:"Intérim",constantGroup:Constant.JOB_TYPE).save()
        new Constant(stringValue:"Apprentissage",constantGroup:Constant.JOB_TYPE).save()
    }

    void  createOccupation() {
        def constant
        constant = new Constant(stringValue:"Administration",constantGroup:Constant.OCCUPATION_TYPE).save()
        new Occupation(name:"Administration système",occupationType:constant.id).save()
        new Occupation(name:"Administration réseaux/telecom",occupationType:constant.id).save()
        new Occupation(name:"Administration base de données",occupationType:constant.id).save()
        new Occupation(name:"Exploitation",occupationType:constant.id).save()
        new Occupation(name:"Sécurité",occupationType:constant.id).save()
        new Occupation(name:"Support/helpDesk",occupationType:constant.id).save()
        constant = new Constant(stringValue:"Production",constantGroup:Constant.OCCUPATION_TYPE).save()
        new Occupation(name:"Gestion de projet",occupationType:constant.id).save()
        new Occupation(name:"Architecture/Urbanisation",occupationType:constant.id).save()
        new Occupation(name:"Etudes/Developpement",occupationType:constant.id).save()
        new Occupation(name:"Internet/Instranet",occupationType:constant.id).save()
        constant = new Constant(stringValue:"informatique Industrielle",constantGroup:Constant.OCCUPATION_TYPE).save()
        new Occupation(name:"CAO/DAO/GPAO",occupationType:constant.id).save()
        new Occupation(name:"Electonique",occupationType:constant.id).save()
        new Occupation(name:"Optique/Optronique",occupationType:constant.id).save()
        constant = new Constant(stringValue:"Fonctionnelle",constantGroup:Constant.OCCUPATION_TYPE).save()
        new Occupation(name:"Décisionnel",occupationType:constant.id).save()
        new Occupation(name:"ERP",occupationType:constant.id).save()
        new Occupation(name:"CRM",occupationType:constant.id).save()
        new Occupation(name:"Finance",occupationType:constant.id).save()
        constant = new Constant(stringValue:"Autre",constantGroup:Constant.OCCUPATION_TYPE).save()
        new Occupation(name:"Commercial",occupationType:constant.id).save()
        new Occupation(name:"Conseil",occupationType:constant.id).save()
        new Occupation(name:"DSI",occupationType:constant.id).save()
        new Occupation(name:"Qualité",occupationType:constant.id).save()
        new Occupation(name:"Management",occupationType:constant.id).save()
    }

    void createCity() {
        new City(area:Area.get(1),name:"Colmar").save()
        new City(area:Area.get(1),name:"Haguenau").save()
        new City(area:Area.get(1),name:"Illkirch-Graffenstaden").save()
        new City(area:Area.get(1),name:"Mulhouse").save()
        new City(area:Area.get(1),name:"Saint-Louis").save()
        new City(area:Area.get(1),name:"Schiltigheim").save()
        new City(area:Area.get(1),name:"Strasbourg").save()
        new City(area:Area.get(2),name:"Agen").save()
        new City(area:Area.get(2),name:"Anglet").save()
        new City(area:Area.get(2),name:"Bayonne").save()
        new City(area:Area.get(2),name:"Bègles").save()
        new City(area:Area.get(2),name:"Bergerac").save()
        new City(area:Area.get(2),name:"Biarritz").save()
        new City(area:Area.get(2),name:"Bordeaux").save()
        new City(area:Area.get(2),name:"Le Bouscat").save()
        new City(area:Area.get(2),name:"Cenon").save()
        new City(area:Area.get(2),name:"Dax").save()
        new City(area:Area.get(2),name:"Gradignan").save()
        new City(area:Area.get(2),name:"Libourne").save()
        new City(area:Area.get(2),name:"Lormont").save()
        new City(area:Area.get(2),name:"Mérignac").save()
        new City(area:Area.get(2),name:"Mont-de-Marsan").save()
        new City(area:Area.get(2),name:"Pau").save()
        new City(area:Area.get(2),name:"Périgueux").save()
        new City(area:Area.get(2),name:"Pessac").save()
        new City(area:Area.get(2),name:"Saint-Médard-en-Jalles").save()
        new City(area:Area.get(2),name:"Talence").save()
        new City(area:Area.get(2),name:"La Teste-de-Buch").save()
        new City(area:Area.get(2),name:"Villenave-d'Ornon").save()
        new City(area:Area.get(2),name:"Villeneuve-sur-Lot").save()
        new City(area:Area.get(3),name:"Aurillac").save()
        new City(area:Area.get(3),name:"Clermont-Ferrand").save()
        new City(area:Area.get(3),name:"Montluçon").save()
        new City(area:Area.get(3),name:"Moulins").save()
        new City(area:Area.get(3),name:"Puy-en-Velay").save()
        new City(area:Area.get(3),name:"Vichy").save()
        new City(area:Area.get(4),name:"Alençon").save()
        new City(area:Area.get(4),name:"Caen").save()
        new City(area:Area.get(4),name:"Cherbourg").save()
        new City(area:Area.get(4),name:"Hérouville-Saint-Clair").save()
        new City(area:Area.get(4),name:"Lisieux").save()
        new City(area:Area.get(4),name:"Octeville").save()
        new City(area:Area.get(4),name:"Saint-Lô").save()
        new City(area:Area.get(5),name:"Autun").save()
        new City(area:Area.get(5),name:"Auxerre").save()
        new City(area:Area.get(5),name:"Beaune").save()
        new City(area:Area.get(5),name:"Chalon-sur-Saône").save()
        new City(area:Area.get(5),name:"Creusot Le Creusot").save()
        new City(area:Area.get(5),name:"Dijon").save()
        new City(area:Area.get(5),name:"Mâcon").save()
        new City(area:Area.get(5),name:"Montceau-les-Mines").save()
        new City(area:Area.get(5),name:"Nevers").save()
        new City(area:Area.get(5),name:"Sens").save()
        new City(area:Area.get(6),name:"Brest").save()
        new City(area:Area.get(6),name:"Concarneau").save()
        new City(area:Area.get(6),name:"Fougères").save()
        new City(area:Area.get(6),name:"Lanester").save()
        new City(area:Area.get(6),name:"Lorient").save()
        new City(area:Area.get(6),name:"Quimper").save()
        new City(area:Area.get(6),name:"Rennes").save()
        new City(area:Area.get(6),name:"Saint-Brieuc").save()
        new City(area:Area.get(6),name:"Saint-Malo").save()
        new City(area:Area.get(6),name:"Vannes").save()
        new City(area:Area.get(7),name:"Blois").save()
        new City(area:Area.get(7),name:"Bourges").save()
        new City(area:Area.get(7),name:"Chartres").save()
        new City(area:Area.get(7),name:"Châteauroux").save()
        new City(area:Area.get(7),name:"Dreux").save()
        new City(area:Area.get(7),name:"Fleury-les-Aubrais").save()
        new City(area:Area.get(7),name:"Joué-lès-Tours").save()
        new City(area:Area.get(7),name:"Olivet").save()
        new City(area:Area.get(7),name:"Orléans").save()
        new City(area:Area.get(7),name:"Tours").save()
        new City(area:Area.get(7),name:"Vierzon").save()
        new City(area:Area.get(8),name:"Châlons-en-Champagne").save()
        new City(area:Area.get(8),name:"Charleville-Mézières").save()
        new City(area:Area.get(8),name:"Chaumont").save()
        new City(area:Area.get(8),name:"Epernay Épernay").save()
        new City(area:Area.get(8),name:"Reims").save()
        new City(area:Area.get(8),name:"Saint-Dizier").save()
        new City(area:Area.get(8),name:"Sedan").save()
        new City(area:Area.get(8),name:"Troyes").save()
        new City(area:Area.get(8),name:"Vitry-le-François").save()
        new City(area:Area.get(9),name:"Ajaccio").save()
        new City(area:Area.get(9),name:"Bastia").save()
        new City(area:Area.get(10),name:"Belfort").save()
        new City(area:Area.get(10),name:"Besançon").save()
        new City(area:Area.get(10),name:"Dole").save()
        new City(area:Area.get(10),name:"Lons-le-Saunier").save()
        new City(area:Area.get(10),name:"Montbéliard").save()
        new City(area:Area.get(23),name:"Abymes Les Abymes").save()
        new City(area:Area.get(23),name:"Baie-Mahault").save()
        new City(area:Area.get(23),name:"Capesterre-Belle-Eau").save()
        new City(area:Area.get(23),name:"Gosier Le Gosier").save()
        new City(area:Area.get(23),name:"Moule Le Moule").save()
        new City(area:Area.get(23),name:"Petit-Bourg").save()
        new City(area:Area.get(23),name:"Pointe-à-Pitre").save()
        new City(area:Area.get(23),name:"Sainte-Anne").save()
        new City(area:Area.get(23),name:"Sainte-Rose").save()
        new City(area:Area.get(23),name:"Cayenne").save()
        new City(area:Area.get(23),name:"Kourou").save()
        new City(area:Area.get(23),name:"Matoury").save()
        new City(area:Area.get(23),name:"Remire-Montjoly").save()
        new City(area:Area.get(23),name:"Saint-Laurent-du-Maroni").save()
        new City(area:Area.get(11),name:"Dieppe").save()
        new City(area:Area.get(11),name:"Evreux Évreux").save()
        new City(area:Area.get(11),name:"Fécamp").save()
        new City(area:Area.get(11),name:"Le Grand-Quevilly").save()
        new City(area:Area.get(11),name:"Havre Le Havre").save()
        new City(area:Area.get(11),name:"Mont-Saint-Aignan").save()
        new City(area:Area.get(11),name:"Le Petit-Quevilly").save()
        new City(area:Area.get(11),name:"Rouen").save()
        new City(area:Area.get(11),name:"Saint-Étienne-du-Rouvray").save()
        new City(area:Area.get(11),name:"Sotteville-lès-Rouen").save()
        new City(area:Area.get(11),name:"Vernon").save()
        new City(area:Area.get(12),name:"Alfortville").save()
        new City(area:Area.get(12),name:"Antony").save()
        new City(area:Area.get(12),name:"Argenteuil").save()
        new City(area:Area.get(12),name:"Asnières-sur-Seine").save()
        new City(area:Area.get(12),name:"Athis-Mons").save()
        new City(area:Area.get(12),name:"Aubervilliers").save()
        new City(area:Area.get(12),name:"Aulnay-sous-Bois").save()
        new City(area:Area.get(12),name:"Bagneux").save()
        new City(area:Area.get(12),name:"Bagnolet").save()
        new City(area:Area.get(12),name:"Bezons").save()
        new City(area:Area.get(12),name:"Le Blanc-Mesnil").save()
        new City(area:Area.get(12),name:"Bobigny").save()
        new City(area:Area.get(12),name:"Bois-Colombes").save()
        new City(area:Area.get(12),name:"Bondy").save()
        new City(area:Area.get(12),name:"Boulogne-Billancourt").save()
        new City(area:Area.get(12),name:"Brétigny-sur-Orge").save()
        new City(area:Area.get(12),name:"Brunoy").save()
        new City(area:Area.get(12),name:"Cachan").save()
        new City(area:Area.get(12),name:"La Celle-Saint-Cloud").save()
        new City(area:Area.get(12),name:"Cergy").save()
        new City(area:Area.get(12),name:"Champigny-sur-Marne").save()
        new City(area:Area.get(12),name:"Champs-sur-Marne").save()
        new City(area:Area.get(12),name:"Charenton-le-Pont").save()
        new City(area:Area.get(12),name:"Châtenay-Malabry").save()
        new City(area:Area.get(12),name:"Châtillon").save()
        new City(area:Area.get(12),name:"Chatou").save()
        new City(area:Area.get(12),name:"Chelles").save()
        new City(area:Area.get(12),name:"Chesnay Le Chesnay").save()
        new City(area:Area.get(12),name:"Choisy-le-Roi").save()
        new City(area:Area.get(12),name:"Clamart").save()
        new City(area:Area.get(12),name:"Clichy").save()
        new City(area:Area.get(12),name:"Clichy-sous-Bois").save()
        new City(area:Area.get(12),name:"Colombes").save()
        new City(area:Area.get(12),name:"Combs-la-Ville").save()
        new City(area:Area.get(12),name:"Conflans-Sainte-Honorine").save()
        new City(area:Area.get(12),name:"Corbeil-Essonnes").save()
        new City(area:Area.get(12),name:"Cormeilles-en-Parisis").save()
        new City(area:Area.get(12),name:"Courbevoie").save()
        new City(area:Area.get(12),name:"Courneuve La Courneuve").save()
        new City(area:Area.get(12),name:"Créteil").save()
        new City(area:Area.get(12),name:"Dammarie-les-Lys").save()
        new City(area:Area.get(12),name:"Deuil-la-Barre").save()
        new City(area:Area.get(12),name:"Drancy").save()
        new City(area:Area.get(12),name:"Draveil").save()
        new City(area:Area.get(12),name:"Eaubonne").save()
        new City(area:Area.get(12),name:"Elancourt").save()
        new City(area:Area.get(12),name:"Epinay-sur-Seine").save()
        new City(area:Area.get(12),name:"Ermont").save()
        new City(area:Area.get(12),name:"Etampes Étampes").save()
        new City(area:Area.get(12),name:"Evry Évry").save()
        new City(area:Area.get(12),name:"Fontenay-aux-Roses").save()
        new City(area:Area.get(12),name:"Fontenay-sous-Bois").save()
        new City(area:Area.get(12),name:"Franconville").save()
        new City(area:Area.get(12),name:"Fresnes").save()
        new City(area:Area.get(12),name:"Gagny").save()
        new City(area:Area.get(12),name:"La Garenne-Colombes").save()
        new City(area:Area.get(12),name:"Garges-lès-Gonesse").save()
        new City(area:Area.get(12),name:"Gennevilliers").save()
        new City(area:Area.get(12),name:"Gif-sur-Yvette").save()
        new City(area:Area.get(12),name:"Gonesse").save()
        new City(area:Area.get(12),name:"Goussainville").save()
        new City(area:Area.get(12),name:"Grigny").save()
        new City(area:Area.get(12),name:"Guyancourt").save()
        new City(area:Area.get(12),name:"Haÿ-les-Roses L'Haÿ-les-Roses").save()
        new City(area:Area.get(12),name:"Herblay").save()
        new City(area:Area.get(12),name:"Houilles").save()
        new City(area:Area.get(12),name:"Issy-les-Moulineaux").save()
        new City(area:Area.get(12),name:"Ivry-sur-Seine").save()
        new City(area:Area.get(12),name:"Le Kremlin-Bicêtre").save()
        new City(area:Area.get(12),name:"Levallois-Perret").save()
        new City(area:Area.get(12),name:"Lilas Les Lilas").save()
        new City(area:Area.get(12),name:"Livry-Gargan").save()
        new City(area:Area.get(12),name:"Longjumeau").save()
        new City(area:Area.get(12),name:"Maisons-Alfort").save()
        new City(area:Area.get(12),name:"Maisons-Laffitte").save()
        new City(area:Area.get(12),name:"Malakoff").save()
        new City(area:Area.get(12),name:"Mantes-la-Jolie").save()
        new City(area:Area.get(12),name:"Massy").save()
        new City(area:Area.get(12),name:"Meaux").save()
        new City(area:Area.get(12),name:"Le Mée-sur-Seine").save()
        new City(area:Area.get(12),name:"Melun").save()
        new City(area:Area.get(12),name:"Meudon").save()
        new City(area:Area.get(12),name:"Montfermeil").save()
        new City(area:Area.get(12),name:"Montgeron").save()
        new City(area:Area.get(12),name:"Montigny-le-Bretonneux").save()
        new City(area:Area.get(12),name:"Montmorency").save()
        new City(area:Area.get(12),name:"Montreuil").save()
        new City(area:Area.get(12),name:"Montrouge").save()
        new City(area:Area.get(12),name:"Morsang-sur-Orge").save()
        new City(area:Area.get(12),name:"Mureaux Les Mureaux").save()
        new City(area:Area.get(12),name:"Nanterre").save()
        new City(area:Area.get(12),name:"Neuilly-sur-Marne").save()
        new City(area:Area.get(12),name:"Neuilly-sur-Seine").save()
        new City(area:Area.get(12),name:"Nogent-sur-Marne").save()
        new City(area:Area.get(12),name:"Noisy-le-Grand").save()
        new City(area:Area.get(12),name:"Noisy-le-Sec").save()
        new City(area:Area.get(12),name:"Orly").save()
        new City(area:Area.get(12),name:"Ozoir-la-Ferrière").save()
        new City(area:Area.get(12),name:"Palaiseau").save()
        new City(area:Area.get(12),name:"Pantin").save()
        new City(area:Area.get(12),name:"Paris").save()
        new City(area:Area.get(12),name:"Les Pavillons-sous-Bois").save()
        new City(area:Area.get(12),name:"Le Perreux-sur-Marne").save()
        new City(area:Area.get(12),name:"Pierrefitte-sur-Seine").save()
        new City(area:Area.get(12),name:"Plaisir").save()
        new City(area:Area.get(12),name:"Le Plessis-Robinson").save()
        new City(area:Area.get(12),name:"Poissy").save()
        new City(area:Area.get(12),name:"Pontault-Combault").save()
        new City(area:Area.get(12),name:"Pontoise").save()
        new City(area:Area.get(12),name:"Puteaux").save()
        new City(area:Area.get(12),name:"Rambouillet").save()
        new City(area:Area.get(12),name:"Ris-Orangis").save()
        new City(area:Area.get(12),name:"Roissy-en-Brie").save()
        new City(area:Area.get(12),name:"Romainville").save()
        new City(area:Area.get(12),name:"Rosny-sous-Bois").save()
        new City(area:Area.get(12),name:"Rueil-Malmaison").save()
        new City(area:Area.get(12),name:"Saint-Cloud").save()
        new City(area:Area.get(12),name:"Saint-Denis").save()
        new City(area:Area.get(12),name:"Sainte-Geneviève-des-Bois").save()
        new City(area:Area.get(12),name:"Saint-Germain-en-Laye").save()
        new City(area:Area.get(12),name:"Saint-Gratien").save()
        new City(area:Area.get(12),name:"Saint-Mandé").save()
        new City(area:Area.get(12),name:"Saint-Maur-des-Fossés").save()
        new City(area:Area.get(12),name:"Saint-Michel-sur-Orge").save()
        new City(area:Area.get(12),name:"Saint-Ouen").save()
        new City(area:Area.get(12),name:"Saint-Ouen-l'Aumône").save()
        new City(area:Area.get(12),name:"Sannois").save()
        new City(area:Area.get(12),name:"Sarcelles").save()
        new City(area:Area.get(12),name:"Sartrouville").save()
        new City(area:Area.get(12),name:"Savigny-le-Temple").save()
        new City(area:Area.get(12),name:"Savigny-sur-Orge").save()
        new City(area:Area.get(12),name:"Sevran").save()
        new City(area:Area.get(12),name:"Sèvres").save()
        new City(area:Area.get(12),name:"Stains").save()
        new City(area:Area.get(12),name:"Sucy-en-Brie").save()
        new City(area:Area.get(12),name:"Suresnes").save()
        new City(area:Area.get(12),name:"Taverny").save()
        new City(area:Area.get(12),name:"Thiais").save()
        new City(area:Area.get(12),name:"Torcy").save()
        new City(area:Area.get(12),name:"Trappes-en-Yvelines").save()
        new City(area:Area.get(12),name:"Tremblay-en-France").save()
        new City(area:Area.get(12),name:"Ulis Les Ulis").save()
        new City(area:Area.get(12),name:"Vanves").save()
        new City(area:Area.get(12),name:"Vélizy-Villacoublay").save()
        new City(area:Area.get(12),name:"Versailles").save()
        new City(area:Area.get(12),name:"Vigneux-sur-Seine").save()
        new City(area:Area.get(12),name:"Villejuif").save()
        new City(area:Area.get(12),name:"Villemomble").save()
        new City(area:Area.get(12),name:"Villeneuve-la-Garenne").save()
        new City(area:Area.get(12),name:"Villeneuve-Saint-Georges").save()
        new City(area:Area.get(12),name:"Villeparisis").save()
        new City(area:Area.get(12),name:"Villepinte").save()
        new City(area:Area.get(12),name:"Villiers-le-Bel").save()
        new City(area:Area.get(12),name:"Villiers-sur-Marne").save()
        new City(area:Area.get(12),name:"Vincennes").save()
        new City(area:Area.get(12),name:"Viry-Châtillon").save()
        new City(area:Area.get(12),name:"Vitry-sur-Seine").save()
        new City(area:Area.get(12),name:"Yerres").save()
        new City(area:Area.get(23),name:"Port Le Port").save()
        new City(area:Area.get(23),name:"La Possession").save()
        new City(area:Area.get(23),name:"Saint-André").save()
        new City(area:Area.get(23),name:"Saint-Benoît").save()
        new City(area:Area.get(23),name:"Saint-Denis").save()
        new City(area:Area.get(23),name:"Sainte-Marie").save()
        new City(area:Area.get(23),name:"Sainte-Suzanne").save()
        new City(area:Area.get(23),name:"Saint-Joseph").save()
        new City(area:Area.get(23),name:"Saint-Leu").save()
        new City(area:Area.get(23),name:"Saint-Louis").save()
        new City(area:Area.get(23),name:"Saint-Paul").save()
        new City(area:Area.get(23),name:"Saint-Pierre").save()
        new City(area:Area.get(23),name:"Le Tampon").save()
        new City(area:Area.get(13),name:"Agde").save()
        new City(area:Area.get(13),name:"Alès").save()
        new City(area:Area.get(13),name:"Béziers").save()
        new City(area:Area.get(13),name:"Carcassonne").save()
        new City(area:Area.get(13),name:"Frontignan").save()
        new City(area:Area.get(13),name:"Lunel").save()
        new City(area:Area.get(13),name:"Montpellier").save()
        new City(area:Area.get(13),name:"Narbonne").save()
        new City(area:Area.get(13),name:"Nîmes").save()
        new City(area:Area.get(13),name:"Perpignan").save()
        new City(area:Area.get(13),name:"Sète").save()
        new City(area:Area.get(14),name:"Brive-la-Gaillarde").save()
        new City(area:Area.get(14),name:"Limoges").save()
        new City(area:Area.get(15),name:"Epinal Épinal").save()
        new City(area:Area.get(15),name:"Forbach").save()
        new City(area:Area.get(15),name:"Lunéville").save()
        new City(area:Area.get(15),name:"Metz").save()
        new City(area:Area.get(15),name:"Montigny-lès-Metz").save()
        new City(area:Area.get(15),name:"Nancy").save()
        new City(area:Area.get(15),name:"Saint-Dié-des-Vosges").save()
        new City(area:Area.get(15),name:"Sarreguemines").save()
        new City(area:Area.get(15),name:"Thionville").save()
        new City(area:Area.get(15),name:"Vandœuvre-lès-Nancy").save()
        new City(area:Area.get(15),name:"Verdun").save()
        new City(area:Area.get(23),name:"Fort-de-France").save()
        new City(area:Area.get(23),name:"Le François").save()
        new City(area:Area.get(23),name:"Le Lamentin").save()
        new City(area:Area.get(23),name:"Le Robert").save()
        new City(area:Area.get(23),name:"Sainte-Marie").save()
        new City(area:Area.get(23),name:"Schoelcher").save()
        new City(area:Area.get(16),name:"Albi").save()
        new City(area:Area.get(16),name:"Auch").save()
        new City(area:Area.get(16),name:"Blagnac").save()
        new City(area:Area.get(16),name:"Cahors").save()
        new City(area:Area.get(16),name:"Castres").save()
        new City(area:Area.get(16),name:"Colomiers").save()
        new City(area:Area.get(16),name:"Millau").save()
        new City(area:Area.get(16),name:"Montauban").save()
        new City(area:Area.get(16),name:"Muret").save()
        new City(area:Area.get(16),name:"Rodez").save()
        new City(area:Area.get(16),name:"Tarbes").save()
        new City(area:Area.get(16),name:"Toulouse").save()
        new City(area:Area.get(16),name:"Tournefeuille").save()
        new City(area:Area.get(17),name:"Armentières").save()
        new City(area:Area.get(17),name:"Arras").save()
        new City(area:Area.get(17),name:"Avion").save()
        new City(area:Area.get(17),name:"Béthune").save()
        new City(area:Area.get(17),name:"Boulogne-sur-Mer").save()
        new City(area:Area.get(17),name:"Bruay-la-Buissière").save()
        new City(area:Area.get(17),name:"Calais").save()
        new City(area:Area.get(17),name:"Cambrai").save()
        new City(area:Area.get(17),name:"Coudekerque-Branche").save()
        new City(area:Area.get(17),name:"Croix").save()
        new City(area:Area.get(17),name:"Denain").save()
        new City(area:Area.get(17),name:"Douai").save()
        new City(area:Area.get(17),name:"Dunkerque").save()
        new City(area:Area.get(17),name:"Grande-Synthe").save()
        new City(area:Area.get(17),name:"Halluin").save()
        new City(area:Area.get(17),name:"Hazebrouck").save()
        new City(area:Area.get(17),name:"Hem").save()
        new City(area:Area.get(17),name:"Hénin-Beaumont").save()
        new City(area:Area.get(17),name:"Lambersart").save()
        new City(area:Area.get(17),name:"Lens").save()
        new City(area:Area.get(17),name:"Liévin").save()
        new City(area:Area.get(17),name:"Lille").save()
        new City(area:Area.get(17),name:"Lomme").save()
        new City(area:Area.get(17),name:"Loos").save()
        new City(area:Area.get(17),name:"La Madeleine").save()
        new City(area:Area.get(17),name:"Marcq-en-Barœul").save()
        new City(area:Area.get(17),name:"Maubeuge").save()
        new City(area:Area.get(17),name:"Mons-en-Barœul").save()
        new City(area:Area.get(17),name:"Roubaix").save()
        new City(area:Area.get(17),name:"Saint-Pol-sur-Mer").save()
        new City(area:Area.get(17),name:"Tourcoing").save()
        new City(area:Area.get(17),name:"Valenciennes").save()
        new City(area:Area.get(17),name:"Villeneuve-d'Ascq").save()
        new City(area:Area.get(17),name:"Wattrelos").save()
        new City(area:Area.get(23),name:"Nouméa").save()
        new City(area:Area.get(21),name:"Aix-en-Provence").save()
        new City(area:Area.get(21),name:"Antibes").save()
        new City(area:Area.get(21),name:"Arles").save()
        new City(area:Area.get(21),name:"Aubagne").save()
        new City(area:Area.get(21),name:"Avignon").save()
        new City(area:Area.get(21),name:"Cagnes-sur-Mer").save()
        new City(area:Area.get(21),name:"Cannes").save()
        new City(area:Area.get(21),name:"Cannet Le Cannet").save()
        new City(area:Area.get(21),name:"Carpentras").save()
        new City(area:Area.get(21),name:"Cavaillon").save()
        new City(area:Area.get(21),name:"La Ciotat").save()
        new City(area:Area.get(21),name:"Draguignan").save()
        new City(area:Area.get(21),name:"Fréjus").save()
        new City(area:Area.get(21),name:"Gap").save()
        new City(area:Area.get(21),name:"Gardanne").save()
        new City(area:Area.get(21),name:"La Garde").save()
        new City(area:Area.get(21),name:"Grasse").save()
        new City(area:Area.get(21),name:"Hyères").save()
        new City(area:Area.get(21),name:"Istres").save()
        new City(area:Area.get(21),name:"Manosque").save()
        new City(area:Area.get(21),name:"Marignane").save()
        new City(area:Area.get(21),name:"Marseille").save()
        new City(area:Area.get(21),name:"Martigues").save()
        new City(area:Area.get(21),name:"Menton").save()
        new City(area:Area.get(21),name:"Miramas").save()
        new City(area:Area.get(21),name:"Nice").save()
        new City(area:Area.get(21),name:"Orange").save()
        new City(area:Area.get(21),name:"Les Pennes-Mirabeau").save()
        new City(area:Area.get(21),name:"Port-de-Bouc").save()
        new City(area:Area.get(21),name:"Saint-Laurent-du-Var").save()
        new City(area:Area.get(21),name:"Saint-Raphaël").save()
        new City(area:Area.get(21),name:"Salon-de-Provence").save()
        new City(area:Area.get(21),name:"La Seyne-sur-Mer").save()
        new City(area:Area.get(21),name:"Six-Fours-les-Plages").save()
        new City(area:Area.get(21),name:"Toulon").save()
        new City(area:Area.get(21),name:"La Valette-du-Var").save()
        new City(area:Area.get(21),name:"Vallauris").save()
        new City(area:Area.get(21),name:"Vitrolles").save()
        new City(area:Area.get(18),name:"Angers").save()
        new City(area:Area.get(18),name:"Cholet").save()
        new City(area:Area.get(18),name:"Laval").save()
        new City(area:Area.get(18),name:"Le Mans").save()
        new City(area:Area.get(18),name:"Nantes").save()
        new City(area:Area.get(18),name:"Orvault").save()
        new City(area:Area.get(18),name:"Rezé").save()
        new City(area:Area.get(18),name:"La Roche-sur-Yon").save()
        new City(area:Area.get(18),name:"Saint-Herblain").save()
        new City(area:Area.get(18),name:"Saint-Nazaire").save()
        new City(area:Area.get(18),name:"Saint-Sébastien-sur-Loire").save()
        new City(area:Area.get(18),name:"Saumur").save()
        new City(area:Area.get(18),name:"Vertou").save()
        new City(area:Area.get(19),name:"Abbeville").save()
        new City(area:Area.get(19),name:"Amiens").save()
        new City(area:Area.get(19),name:"Beauvais").save()
        new City(area:Area.get(19),name:"Compiègne").save()
        new City(area:Area.get(19),name:"Creil").save()
        new City(area:Area.get(19),name:"Laon").save()
        new City(area:Area.get(19),name:"Saint-Quentin").save()
        new City(area:Area.get(19),name:"Soissons").save()
        new City(area:Area.get(20),name:"Angoulême").save()
        new City(area:Area.get(20),name:"Châtellerault").save()
        new City(area:Area.get(20),name:"Cognac").save()
        new City(area:Area.get(20),name:"Niort").save()
        new City(area:Area.get(20),name:"Poitiers").save()
        new City(area:Area.get(20),name:"Rochefort").save()
        new City(area:Area.get(20),name:"La Rochelle").save()
        new City(area:Area.get(20),name:"Saintes").save()
        new City(area:Area.get(22),name:"Aix-les-Bains").save()
        new City(area:Area.get(22),name:"Annecy").save()
        new City(area:Area.get(22),name:"Annecy-le-Vieux").save()
        new City(area:Area.get(22),name:"Annemasse").save()
        new City(area:Area.get(22),name:"Bourg-en-Bresse").save()
        new City(area:Area.get(22),name:"Bourgoin-Jallieu").save()
        new City(area:Area.get(22),name:"Bron").save()
        new City(area:Area.get(22),name:"Caluire-et-Cuire").save()
        new City(area:Area.get(22),name:"Chambéry").save()
        new City(area:Area.get(22),name:"Décines-Charpieu").save()
        new City(area:Area.get(22),name:"Echirolles Échirolles").save()
        new City(area:Area.get(22),name:"Firminy").save()
        new City(area:Area.get(22),name:"Fontaine").save()
        new City(area:Area.get(22),name:"Givors").save()
        new City(area:Area.get(22),name:"Grenoble").save()
        new City(area:Area.get(22),name:"Lyon").save()
        new City(area:Area.get(22),name:"Meyzieu").save()
        new City(area:Area.get(22),name:"Montélimar").save()
        new City(area:Area.get(22),name:"Oullins").save()
        new City(area:Area.get(22),name:"Oyonnax").save()
        new City(area:Area.get(22),name:"Rillieux-la-Pape").save()
        new City(area:Area.get(22),name:"Roanne").save()
        new City(area:Area.get(22),name:"Romans-sur-Isère").save()
        new City(area:Area.get(22),name:"Saint-Chamond").save()
        new City(area:Area.get(22),name:"Sainte-Foy-lès-Lyon").save()
        new City(area:Area.get(22),name:"Saint-Étienne").save()
        new City(area:Area.get(22),name:"Saint-Genis-Laval").save()
        new City(area:Area.get(22),name:"Saint-Martin-d'Hères").save()
        new City(area:Area.get(22),name:"Saint-Priest").save()
        new City(area:Area.get(22),name:"Thonon-les-Bains").save()
        new City(area:Area.get(22),name:"Valence").save()
        new City(area:Area.get(22),name:"Vaulx-en-Velin").save()
        new City(area:Area.get(22),name:"Vénissieux").save()
        new City(area:Area.get(22),name:"Vienne").save()
        new City(area:Area.get(22),name:"Villefranche-sur-Saône").save()
        new City(area:Area.get(22),name:"Villeurbanne").save()
        new City(area:Area.get(22),name:"Voiron").save()
        new City(area:Area.get(23),name:"Saint-Martin").save()

    }



    void createArea() {
        def country = Country.get(1);
        new Area(country: country, name: "Alsace").save();
        new Area(country: country, name: "Aquitaine").save();
        new Area(country: country, name: "Auvergne").save();
        new Area(country: country, name: "Basse-Normandie").save();
        new Area(country: country, name: "Bourgogne").save();
        new Area(country: country, name: "Bretagne").save();
        new Area(country: country, name: "Centre").save();
        new Area(country: country, name: "Champagne-Ardenne").save();
        new Area(country: country, name: "Corse").save();
        new Area(country: country, name: "Franche-Comté").save();
        new Area(country: country, name: "Haute-Normandie").save();
        new Area(country: country, name: "Ile-de-France").save();
        new Area(country: country, name: "Languedoc-Roussillon").save();
        new Area(country: country, name: "Limousin").save();
        new Area(country: country, name: "Lorraine").save();
        new Area(country: country, name: "Midi-Pyrénées").save();
        new Area(country: country, name: "Nord-Pas-de-Calais").save();
        new Area(country: country, name: "Pays de la Loire").save();
        new Area(country: country, name: "Picardie").save();
        new Area(country: country, name: "Poitou-Charentes").save();
        new Area(country: country, name: "Provence-Alpes-Côte d'Azur").save();
        new Area(country: country, name: "Rhône-Alpes").save();
        new Area(country: country, name: "DOM-TOM").save()
    }

    void createCountry() {
        new Country(name: "France").save()
    }
}
