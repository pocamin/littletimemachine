class ConstantController {

    boolean visible = true;

    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']

    def list = {
        if(!params.max) params.max = 10
        [ constantList: Constant.list( params ) ]
    }

    def delete = {
        def constant = Constant.get( params.id )
        if(constant) {
            constant.delete()
            flash.message = "Constant ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "Constant not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def constant = Constant.get( params.id )

        if(!constant) {
            flash.message = "Constant not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ constant : constant ]
        }
    }

    def update = {
        def constant = Constant.get( params.id )
        if(constant) {
            constant.properties = params
            if(!constant.hasErrors() && constant.save()) {
                flash.message = "Constant ${params.id} updated"
                redirect(action:list,id:constant.id)
            }
            else {
                render(view:'edit',model:[constant:constant])
            }
        }
        else {
            flash.message = "Constant not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        def constant = new Constant()
        constant.properties = params
        return ['constant':constant]
    }

    def save = {
        def constant = new Constant(params)
        if(!constant.hasErrors() && constant.save()) {
            flash.message = "Constant ${constant.id} created"
            redirect(action:list,id:constant.id)
        }
        else {
            render(view:'create',model:[constant:constant])
        }
    }
}