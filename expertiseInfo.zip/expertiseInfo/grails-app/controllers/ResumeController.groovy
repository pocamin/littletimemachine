class ResumeController {
    
    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']

    def list = {
        if(!params.max) params.max = 10
        [ resumeList: Resume.list( params ) ]
    }

    def deleteStudy = {
        session.studies.remove(new Integer(params.id))
        render(template:"study")
        
    }

    def deleteExp = {
        session.expPro.remove(new Integer(params.id))
        render(template:"expPro")

    }

    def addExp = {
        println("ok");
        if (params.description == null)
            params.remove('description')

        ProfessionalExperience exp = new ProfessionalExperience(params);

        Firm firm = Firm.findByNameIlike(params.firm)
        if (firm == null){
            if (!"".equals(params.firm)){
                firm = new Firm(name:params.firm)
                firm.save()
            }
        }

        if (firm != null){
            exp.firm = firm;
        }

        if (session.expPro == null){
            session.expPro = []
        }
        session.expPro += exp


        render(template:"expPro")
    }


    def addStudy = {

        if (params.description == null)
            params.remove('description')

        def study = new Study(params)
        Diploma diploma = Diploma.findByNameIlike(params.diploma)
        if (!diploma){
            if (!"".equals(params.diploma)){
              diploma = new Diploma(name:params.diploma)
            }
        }
        if (diploma != null){
            study.diploma= diploma;
        }

        School school = School.findByNameIlike(params.school)
        if (!school){
            if (!"".equals(params.school)){
              school = new School(name:params.school)
            }
        }
        if (school != null){
            study.school= school;
        }

        if (study.school != null && study.diploma != null) {
            if (session.studies == null){
                session.studies = []
            }
            session.studies += study
        }

        render(template:"study")
    }



    def show = {
        def resume = Resume.get( params.id )

        if(!resume) {
            flash.message = "Resume not found with id ${params.id}"
            redirect(action:list)
        }
        else { return [ resume : resume ] }
    }

    def delete = {
        def resume = Resume.get( params.id )
        if(resume) {
            resume.delete()
            flash.message = "Resume ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "Resume not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def resume = Resume.get( params.id )

        if(!resume) {
            flash.message = "Resume not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ resume : resume ]
        }
    }

    def update = {
        def resume = Resume.get( params.id )
        if(resume) {
            resume.properties = params
            if(!resume.hasErrors() && resume.save()) {
                flash.message = "Resume ${params.id} updated"
                redirect(action:show,id:resume.id)
            }
            else {
                render(view:'edit',model:[resume:resume])
            }
        }
        else {
            flash.message = "Resume not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        def resume = new Resume()
        resume.properties = params
        resume.applicant = ApplicantAccount.get(session.applicant)
        return ['resume':resume]
    }

    def save = {
        def resume = new Resume(params)
        if(!resume.hasErrors() && resume.save()) {
            flash.message = "Resume ${resume.id} created"
            redirect(action:show,id:resume.id)
        }
        else {
            render(view:'create',model:[resume:resume])
        }
    }
}
