            
class JobOfferController {

    boolean visible = true;

    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']

    def list = {
        if(!params.max) params.max = 10
        [ jobOfferList: JobOffer.list( params ) ]
    }

    def addRequieredSkills = {

        if (params.requieredSkillsAjax != null && params.requieredSkillsAjax.length() > 0){
            def skillType = getSkillType(params.requieredSkillsAjax)

            session.requieredSkills = addSkill(session.requieredSkills, skillType, session.preferredSkills)

            render(template:"skills",model:[name:'ajaxRSkill',skills:session.requieredSkills]);
        }

    }

    def addPreferredSkills = {

        if (params.preferredSkillsAjax != null && params.preferredSkillsAjax.length() > 0){
            def skillType = getSkillType(params.preferredSkillsAjax)

            session.preferredSkills = addSkill(session.preferredSkills, skillType, session.requieredSkills)

            render(template:"skills",model:[name:'ajaxPSkill',skills:session.preferredSkills]);
        }

    }


    def deleteSkillajaxPSkill = {

        session.preferredSkills.each{
            if (String.valueOf(it.id).equals(params.id)){
               session.preferredSkills -= it
            }
        }
        render(template:"skills",model:[name:'ajaxPSkill',skills:session.preferredSkills]);
    }

    def deleteSkillajaxRSkill = {

        session.requieredSkills.each{
            if (String.valueOf(it.id).equals(params.id)){
               session.requieredSkills -= it
            }
        }

        

        render(template:"skills",model:[name:'ajaxRSkill',skills:session.requieredSkills]);
    }



    private def addSkill(toAdd, skillType, tocheck) {
        if (!toAdd.find { it.name.equals(skillType.name)} &&
                !tocheck.find { it.name.equals(skillType.name)}) {
            toAdd += skillType;
        } else {
            render "<div class='errors'><ul><li>Vous avez déja renseigné cette compétence</li></ul></div>"
        }
        return toAdd;
    }


    private def getSkillType(String value) {
        def skillType = SkillType.find("from SkillType as s where upper(s.name) = ?", value.toUpperCase())

        if (!skillType) {
            skillType = new SkillType(name: value, skillDomain: 0);
            skillType.save()
        }
        return skillType
    }


    def show = {
        def jobOffer = JobOffer.get( params.id )

        if(!jobOffer) {
            flash.message = "JobOffer not found with id ${params.id}"
            redirect(action:list)
        }
        else { return [ jobOffer : jobOffer ] }
    }

    def delete = {
        def jobOffer = JobOffer.get( params.id )
        if(jobOffer) {
            jobOffer.delete()
            flash.message = "JobOffer ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "JobOffer not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def jobOffer = JobOffer.get( params.id )

        if(!jobOffer) {
            flash.message = "JobOffer not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ jobOffer : jobOffer ]
        }
    }

    def update = {
        def jobOffer = JobOffer.get( params.id )
        if(jobOffer) {
            jobOffer.properties = params
            if(!jobOffer.hasErrors() && jobOffer.save()) {
                flash.message = "JobOffer ${params.id} updated"
                redirect(action:show,id:jobOffer.id)
            }
            else {
                render(view:'edit',model:[jobOffer:jobOffer])
            }
        }
        else {
            flash.message = "JobOffer not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        def jobOffer = new JobOffer()
        jobOffer.properties = params
        jobOffer.city =  jobOffer.firm?.city
        if (!session.requieredSkills){
            session.requieredSkills = jobOffer.requieredSkills
            session.preferredSkills = jobOffer.preferredSkills
        }
        if (!session.requieredSkills){
            session.requieredSkills = []
            session.preferredSkills = []
        }
        return ['jobOffer':jobOffer]
    }




    def save = {
        if ("".equals(params["id"])){
            params["id"] = null
        }

        if ("".equals(params["occupation.id"])){
            params.remove("occupation.id")
        }

        params["city.id"] =  params["cac.city"]

        if (params["id"] == null)
            params.remove("id");

        if (params["city.id"] == null){
            params.remove("city.id");
            //render(view:'create',model:[jobOffer:jobOffer])
        }
        println(params)
        def jobOffer = new JobOffer();
        jobOffer.properties = params

        jobOffer.requieredSkills.removeAll();
        jobOffer.requieredSkills.addAll(session.requieredSkills)
        jobOffer.preferredSkills.addAll(session.preferredSkills) 




        if(!jobOffer.hasErrors() && jobOffer.save()) {
            flash.message = "JobOffer ${jobOffer.id} created"
            println(jobOffer.preferredSkills)
            session.requieredSkills = []
            session.preferredSkills = []
            redirect(action:show,id:jobOffer.id)
        }
        else {
            render(view:'create',model:[jobOffer:jobOffer])
        }
    }
}