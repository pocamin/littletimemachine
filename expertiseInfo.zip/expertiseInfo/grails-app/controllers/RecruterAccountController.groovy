class RecruterAccountController {
    
    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']

    def list = {
        if(!params.max) params.max = 10
        [ recruterAccountList: RecruterAccount.findAll("from RecruterAccount r where r.firm = ?", [Firm.get(session.firm)] , params ) ]
    }

    def show = {
        def recruterAccount = RecruterAccount.get( params.id )

        if(!recruterAccount) {
            flash.message = "RecruterAccount not found with id ${params.id}"
            redirect(action:list)
        }
        else { return [ recruterAccount : recruterAccount ] }
    }

    def delete = {
        /*
        def recruterAccount = RecruterAccount.get( params.id )
        if(recruterAccount) {
            recruterAccount.delete()
            flash.message = "RecruterAccount ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "RecruterAccount not found with id ${params.id}"
            redirect(action:list)
        }    */
    }

    def edit = {
        def recruterAccount = RecruterAccount.get( params.id )
        if (recruterAccount.firm.id.equals(session.firm)){
            if(!recruterAccount) {
                flash.message = "RecruterAccount not found with id ${params.id}"
                redirect(action:list)
            }
            else {
                return [ recruterAccount : recruterAccount ]
            }
        } else {
            session.invalidate();
            flash.message = "Le recruteur n'appartient pas à votre entreprise";            
            redirect(controller:'firm',action:"connect",id:recruterAccount.firm.id)         
        }
    }

    def update = {

        normalizeParams(params)
        def recruterAccount = RecruterAccount.get( params.id )
        if (recruterAccount.firm.id.equals(session.firm)){
            if(recruterAccount) {
                recruterAccount.properties = params
                if(!recruterAccount.hasErrors() && recruterAccount.save()) {
                    flash.message = "Mise à jour effectuée"
                    redirect(action:show,id:recruterAccount.id)
                }
                else {
                    render(view:'edit',model:[recruterAccount:recruterAccount])
                }
            }
            else {
                flash.message = "RecruterAccount not found with id ${params.id}"
                redirect(action:edit,id:params.id)
            }
        } else {
            session.invalidate();
            flash.message = "Le recruteur n'appartient pas à votre entreprise";            
            redirect(controller:'firm',action:"connect",id:recruterAccount.firm.id)
        }
    }

    def create = {
        def recruterAccount = new RecruterAccount()
        recruterAccount.properties = params
        recruterAccount.firm = Firm.get(session.firm)        
        return ['recruterAccount':recruterAccount]
    }

    def save = {
        normalizeParams(params)

        def recruterAccount = new RecruterAccount(params)
        Firm firm =  Firm.get(session.firm);

        recruterAccount.firm = firm
        firm.recruters += recruterAccount

        if (recruterAccount.firm != null){
            if(!recruterAccount.hasErrors() &&  recruterAccount.save()) {
                flash.message = "Recruteur créé"
                redirect(action:list,id:recruterAccount.id)
            }
            else {
                render(view:'create',model:[recruterAccount:recruterAccount])
            }
        } else redirect(view:'connect');
        

    }

    private Map normalizeParams(Map params) {
        return params.each {key, value ->
            if ("".equals(value)) {
                params.put(key, null);
            }
        }
    }
}
