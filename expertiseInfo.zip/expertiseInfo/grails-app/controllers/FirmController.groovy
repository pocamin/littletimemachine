import javax.servlet.http.HttpServletRequest
import org.codehaus.groovy.grails.web.servlet.FlashScope

class FirmController {

    boolean visible = true;

    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']

    def list = {
        if(!params.max) params.max = 10
        [ firmList: Firm.list( params ) ]
    }

    def connect = {
        if (params.code != null){
            Firm firm = Firm.get(params.id);
            if (firm){
                String str = UtilMethods.getValidationCode(firm);
                if (str.equals(params.code)){
                    session.firm = firm.id

                    if (firm.recruters.size() < 1){
                       flash.message = "Vous n'avez pas encore créer de recruteur pour cette entreprise"
                       redirect(controller:"recruterAccount",action:"create")
                    }
                    else redirect(action:edit);
                } else {
                    
                }

            }



            
        }
    }

    def show = {
        def firm = Firm.get( params.id )

        if(!firm) {
            flash.message = "Firm not found with id ${params.id}"
            redirect(action:list)
        }
        else { return [ firm : firm ] }
    }

    def delete = {
        def firm = Firm.get( params.id )
        if(firm) {
            firm.delete()
            flash.message = "Firm ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "Firm not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def firm = Firm.get( session.firm )

        if(!firm) {
            flash.message = "Firm not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ firm : firm ]
        }
    }

    def logo = {
      Firm firm = Firm.get( params.id )
      if (!firm || !firm.logo || !firm.logoContentType) {
        response.sendError(404)
        return;
      }
      response.setContentType(firm.logoContentType)
      response.setContentLength(firm.logo.size())
      OutputStream out = response.getOutputStream();
      out.write(firm.logo);
      out.close();
    }


    def update = {
        Firm firm = Firm.get( params.id )
        if(firm) {

            // Gestion du logo
            if ("newlogo".equals(params.logoSelection)){
                def f = request.getFile('file')
                def okcontents = ['image/png', 'image/jpeg', 'image/gif']
                if (!okcontents.contains(f.getContentType())) {
                    flash.message = "Le logo n'est pas de type: ${okcontents}"
                    render(view: 'edit', model: [firm: firm])
                    return;
                }
                firm.logo = f.getBytes()
                firm.logoContentType = f.getContentType()
            } else if ("noLogo".equals(params.logoSelection)){
                firm.logo = null
                firm.logoContentType = null                
            }

            //gestion de la ville
            println(params);
            if (params["cac.city"] != null){
               firm.city = City.get(params["cac.city"]) 
            }



            //Autre
            firm.properties = params
            if(!firm.hasErrors() && firm.save()) {
                flash.message = "Mise à jour effectuée"
                redirect(action:show,id:firm.id)
            }
            else {
                render(view:'edit',model:[firm:firm])
            }
        }
        else {
            flash.message = "Firm not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        def firm = new Firm()
        firm.properties = params
        return ['firm':firm]
    }

    def save = {
        def firm = new Firm(params)
        if(!firm.hasErrors() && firm.save()) {
            flash.message = "Firm ${firm.id} created"
            redirect(action:show,id:firm.id)
        }
        else {
            render(view:'create',model:[firm:firm])
        }
    }
}