            
class CountryController {
    
    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']

    def list = {
        if(!params.max) params.max = 10
        [ countryList: Country.list( params ) ]
    }

    def show = {
        def country = Country.get( params.id )

        if(!country) {
            flash.message = "Country not found with id ${params.id}"
            redirect(action:list)
        }
        else { return [ country : country ] }
    }

    def delete = {
        def country = Country.get( params.id )
        if(country) {
            country.delete()
            flash.message = "Country ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "Country not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def country = Country.get( params.id )

        if(!country) {
            flash.message = "Country not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ country : country ]
        }
    }

    def update = {
        def country = Country.get( params.id )
        if(country) {
            country.properties = params
            if(!country.hasErrors() && country.save()) {
                flash.message = "Country ${params.id} updated"
                redirect(action:show,id:country.id)
            }
            else {
                render(view:'edit',model:[country:country])
            }
        }
        else {
            flash.message = "Country not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        def country = new Country()
        country.properties = params
        return ['country':country]
    }

    def save = {
        def country = new Country(params)
        if(!country.hasErrors() && country.save()) {
            flash.message = "Country ${country.id} created"
            redirect(action:show,id:country.id)
        }
        else {
            render(view:'create',model:[country:country])
        }
    }
}