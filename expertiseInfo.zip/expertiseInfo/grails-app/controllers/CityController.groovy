            
class CityController {
    
    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']


    def countryChoosedAJAX = {
        session["cac.area"] = null;
        if ( params.country != null && !params.country.equals("") ){
            session["cac.country"] = params.country;
        } else session["cac.country"] = null 

        render (template:"/cityTemplate")
    }

    def areaChoosedAJAX = {
        if ( params.area != null && !params.area.equals("") ){
            session["cac.area"] = params.area;
        } else session["cac.area"] = null
        render (template:"/cityTemplate")    
    }


    def searchAJAX = {

        String s = "%" + String.valueOf(params.query).toUpperCase() + "%";
        def cities = City.findAll("from City as c where c.area = ? and upper(c.name) like ? ",[Area.get(session["cac.area"]),s]);
        //ByNameLike("%${params.query}%")

        render(contentType: "text/xml") {
            results() {
                cities.each { city ->
                    result(){
                        name(city.name)
                    }
                }
            }
        }
    }


    def list = {
        if(!params.max) params.max = 10
        [ cityList: City.list( params ) ]
    }

    def show = {
        def city = City.get( params.id )

        if(!city) {
            flash.message = "City not found with id ${params.id}"
            redirect(action:list)
        }
        else { return [ city : city ] }
    }

    def delete = {
        def city = City.get( params.id )
        if(city) {
            city.delete()
            flash.message = "City ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "City not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def city = City.get( params.id )

        if(!city) {
            flash.message = "City not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ city : city ]
        }
    }

    def update = {
        def city = City.get( params.id )
        if(city) {
            city.properties = params
            if(!city.hasErrors() && city.save()) {
                flash.message = "City ${params.id} updated"
                redirect(action:show,id:city.id)
            }
            else {
                render(view:'edit',model:[city:city])
            }
        }
        else {
            flash.message = "City not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        def city = new City()
        city.properties = params
        return ['city':city]
    }

    def save = {
        def city = new City(params)
        if(!city.hasErrors() && city.save()) {
            flash.message = "City ${city.id} created"
            redirect(action:show,id:city.id)
        }
        else {
            render(view:'create',model:[city:city])
        }
    }
}