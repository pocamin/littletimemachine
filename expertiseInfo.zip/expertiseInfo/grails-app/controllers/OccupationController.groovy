            
class OccupationController {
    
    def index = { redirect(action:list,params:params) }

    // the delete, save and update actions only accept POST requests
    def allowedMethods = [delete:'POST', save:'POST', update:'POST']

    def list = {
        if(!params.max) params.max = 10
        [ occupationList: Occupation.list( params ) ]
    }


    def delete = {
        def occupation = Occupation.get( params.id )
        if(occupation) {
            occupation.delete()
            flash.message = "Occupation ${params.id} deleted"
            redirect(action:list)
        }
        else {
            flash.message = "Occupation not found with id ${params.id}"
            redirect(action:list)
        }
    }

    def edit = {
        def occupation = Occupation.get( params.id )

        if(!occupation) {
            flash.message = "Occupation not found with id ${params.id}"
            redirect(action:list)
        }
        else {
            return [ occupation : occupation ]
        }
    }

    def update = {
        def occupation = Occupation.get( params.id )
        if(occupation) {
            occupation.properties = params
            if(!occupation.hasErrors() && occupation.save()) {
                flash.message = "Occupation ${params.id} updated"
                redirect(action:list,id:occupation.id)
            }
            else {
                render(view:'edit',model:[occupation:occupation])
            }
        }
        else {
            flash.message = "Occupation not found with id ${params.id}"
            redirect(action:edit,id:params.id)
        }
    }

    def create = {
        def occupation = new Occupation()
        occupation.properties = params
        return ['occupation':occupation]
    }

    def save = {
        def occupation = new Occupation(params)
        if(!occupation.hasErrors() && occupation.save()) {
            flash.message = "Occupation ${occupation.id} created"
            redirect(action:list,id:occupation.id)
        }
        else {
            render(view:'create',model:[occupation:occupation])
        }
    }
}