class FlowTagLibTests extends GroovyTestCase {

    void testSomething() {

    }
}
