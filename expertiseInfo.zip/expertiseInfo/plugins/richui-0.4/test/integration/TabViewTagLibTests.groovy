class TabViewTagLibTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
