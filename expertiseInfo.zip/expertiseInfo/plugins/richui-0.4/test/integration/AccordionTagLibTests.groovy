class AccordionTagLibTests extends GroovyTestCase {

    void testSomething() {

    }
}
