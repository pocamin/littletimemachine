class PortletTagLibTests extends GroovyTestCase {

    void testSomething() {

    }
}
