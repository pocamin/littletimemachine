class ResourceTagLibTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
