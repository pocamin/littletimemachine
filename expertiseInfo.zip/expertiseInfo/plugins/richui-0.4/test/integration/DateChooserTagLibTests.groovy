import java.text.SimpleDateFormat

class DateChooserTagLibTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
