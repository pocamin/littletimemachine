class CalendarTagLibTests extends GroovyTestCase {

    void testSomething() {

    }
}
